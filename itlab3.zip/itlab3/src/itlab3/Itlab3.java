package itlab3;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class Itlab3 extends Application {
    private Object math;
    
    @Override
    public void start(Stage primaryStage) {
        Button addButton = new Button("+");
        Button subButton=new Button("-");
        Button multButton =new Button("*");
        Button divButton =new Button("/");
        Button clearButton =new Button("c");
        Button squButton=new Button("R");
        TextField num1Field=new TextField();
        num1Field.setPromptText("enter num1:");
        TextField num2Field=new TextField();
        num2Field.setPromptText("enter num2:");
        Label resultLabel1=new Label("Result");
        addButton.setOnAction(new EventHandler<ActionEvent>()
        {
            public void handle(ActionEvent e)
            {
                calculate(num1Field,num2Field,resultLabel1,"+");
            }
        });
        addButton.setOnAction(e->calculate(num1Field,num2Field,resultLabel1,"+"));
        subButton.setOnAction(e->calculate(num1Field,num2Field,resultLabel1,"-"));
        multButton.setOnAction(e->calculate(num1Field,num2Field,resultLabel1,"*"));
        divButton.setOnAction(e->calculate(num1Field,num2Field,resultLabel1,"/"));
        clearButton.setOnAction(e->calculate(num1Field,num2Field,resultLabel1,"c"));
        squButton.setOnAction(e->calculate(num1Field,num2Field,resultLabel1,"R"));
        
        HBox buttonBox=new HBox(10,addButton,subButton,multButton,divButton,clearButton,squButton);
        VBox root=new VBox(num1Field,num2Field,resultLabel1,buttonBox);
        Scene scene=new Scene(root,300,250);
        primaryStage.setTitle("simple Arthimetic Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
        private void calculate(TextField t1,TextField t2,Label result,String op)
        {
        float num1=Float.parseFloat(t1.getText());
        float num2=Float.parseFloat(t2.getText());
        float finalResult=0;
        switch(op)
        {
            case"+":
            finalResult=num1+num2;
            break;
            case"-":
            finalResult=num1-num2;
            break;
            case"*":
            finalResult=num1*num1;
            break;
             case"R":
              finalResult= num1*num1;
              break;
            case"/":
            {
           
            if(num2==0);
            {
            result.setText("Error:Division by zero");
            
        }
            finalResult=num1/num2;
            break;
        }
        case"clear":{
        t1.clear();
        t2.clear();
            
        }}
        
        result.setText("Result:"+finalResult);
        }
    public static void main(String[] args) {
        launch(args);
    }
    
}
